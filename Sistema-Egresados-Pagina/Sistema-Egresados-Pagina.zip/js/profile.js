window.onload = () =>{
  const grid = document.querySelector('.grid',{
  });

  const masonry = new Masonry(grid);
}

document.getElementById("profile-picture").onchange = function() {
    
    document.getElementById("profile-picture").submit();
};

