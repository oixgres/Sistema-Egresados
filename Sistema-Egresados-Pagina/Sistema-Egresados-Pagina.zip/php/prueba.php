<?php

echo gettype(1);

?>